<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';
require_login();

$root = realpath(__DIR__ . '/..');

$allowed = [
    'index.php' => $root . '/index.php',
    'styles.css' => $root . '/styles.css',
    'index.html' => $root . '/index.html',
    '.htaccess' => $root . '/.htaccess',
    'admin/index.php' => $root . '/admin/index.php',
    'admin/inspo.php' => $root . '/admin/inspo.php',
    'admin/edit.php' => $root . '/admin/edit.php',
    'admin/page.php' => $root . '/admin/page.php',
];

$message = '';
$error = '';

function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        http_response_code(400);
        exit('CSRF invalid');
    }
    $key = $_POST['target'] ?? '';
    if (!isset($allowed[$key])) {
        $error = 'Fisier invalid.';
    } elseif (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Incarcarea a esuat.';
    } else {
        $dest = $allowed[$key];
        $tmp = $_FILES['file']['tmp_name'];
        if (!move_uploaded_file($tmp, $dest)) {
            $error = 'Nu am putut salva fisierul.';
        } else {
            $message = 'Fisier actualizat: ' . $key;
        }
    }
}
?>
<!doctype html>
<html lang="ro">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Upload fisiere</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Crimson+Pro:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: "Crimson Pro", serif; background: #FFFDF7; color: #1c1c1c; }
    .wrap { max-width: 820px; margin: 60px auto; padding: 24px; }
    .card { background: #fffaf2; border: 1px solid #efe6d6; border-radius: 16px; padding: 24px; }
    label { display: block; margin: 12px 0 6px; font-weight: 600; }
    select, input[type=file] { width: 100%; padding: 10px 12px; border-radius: 10px; border: 1px solid #d9d0c2; font-size: 16px; }
    .btn { margin-top: 16px; background: #111; color: #fff; border: 0; border-radius: 10px; padding: 10px 16px; font-size: 16px; }
    .link { text-decoration: none; color: #111; }
    .msg { margin: 12px 0; padding: 10px 12px; border-radius: 8px; }
    .ok { background: #eef8ee; border: 1px solid #cfe8cf; }
    .err { background: #fdecec; border: 1px solid #f3caca; }
  </style>
</head>
<body>
  <div class="wrap">
    <a class="link" href="/admin/">← inapoi</a>
    <div class="card">
      <h1>Upload fisiere</h1>
      <p>Permite actualizarea rapida doar a fisierelor permise.</p>
      <?php if ($message): ?><div class="msg ok"><?php echo h($message); ?></div><?php endif; ?>
      <?php if ($error): ?><div class="msg err"><?php echo h($error); ?></div><?php endif; ?>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
        <label for="target">Fisier</label>
        <select id="target" name="target" required>
          <?php foreach ($allowed as $key => $path): ?>
            <option value="<?php echo h($key); ?>"><?php echo h($key); ?></option>
          <?php endforeach; ?>
        </select>
        <label for="file">Incarca</label>
        <input id="file" type="file" name="file" required>
        <button class="btn" type="submit">Uploadeaza</button>
      </form>
    </div>
  </div>
</body>
</html>
