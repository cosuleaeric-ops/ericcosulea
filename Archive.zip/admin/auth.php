<?php
declare(strict_types=1);

session_start();

function config(): array {
    return require __DIR__ . '/config.php';
}

function is_logged_in(): bool {
    return !empty($_SESSION['admin_logged_in']);
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: /admin/login.php');
        exit;
    }
}

function verify_password(string $password): bool {
    $cfg = config();
    $hash = hash('sha256', $password);
    return hash_equals($cfg['password_sha256'], $hash);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
