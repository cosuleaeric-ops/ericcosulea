<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';
require_login();

$dbPath = __DIR__ . '/../data/blog.sqlite';
$db = new SQLite3($dbPath);
$db->exec('CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    content_html TEXT NOT NULL,
    content_md TEXT,
    excerpt TEXT,
    published_at TEXT NOT NULL
);');
@$db->exec('ALTER TABLE posts ADD COLUMN content_md TEXT;');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        http_response_code(400);
        exit('CSRF invalid');
    }
    $stmt = $db->prepare('DELETE FROM posts WHERE id = :id');
    $stmt->bindValue(':id', (int)$_POST['delete_id'], SQLITE3_INTEGER);
    $stmt->execute();
    header('Location: /admin/');
    exit;
}

$result = $db->query('SELECT id, slug, title, published_at FROM posts ORDER BY published_at DESC');
$posts = [];
while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $posts[] = $row;
}

function h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="ro">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Crimson+Pro:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: "Crimson Pro", serif; background: #FFFDF7; color: #1c1c1c; }
    .wrap { max-width: 820px; margin: 60px auto; padding: 24px; }
    .top { display: flex; justify-content: space-between; align-items: center; }
    .btn { background: #111; color: #fff; border: 0; border-radius: 10px; padding: 8px 14px; font-size: 16px; text-decoration: none; }
    .list { margin-top: 20px; display: flex; flex-direction: column; gap: 10px; }
    .item { background: #fffaf2; border: 1px solid #efe6d6; border-radius: 12px; padding: 12px 14px; display: flex; justify-content: space-between; align-items: baseline; }
    .item a { color: #111; text-decoration: none; font-weight: 600; }
    .meta { color: #6d6a64; font-size: 14px; }
    .actions { display: flex; gap: 10px; align-items: center; }
    .link { text-decoration: none; color: #111; font-size: 14px; }
    .danger { background: #f4d6d6; border: 0; padding: 6px 10px; border-radius: 8px; cursor: pointer; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="top">
      <h1>Admin</h1>
      <div class="actions">
        <a class="btn" href="/admin/inspo.php">Inspo</a>
        <a class="btn" href="/admin/page.php?slug=tools">Tools</a>
        <a class="btn" href="/admin/edit.php">Articol nou</a>
        <a class="btn" href="/admin/files.php">Fisiere</a>
        <a class="link" href="/admin/logout.php">Logout</a>
      </div>
    </div>
    <div class="list">
      <?php foreach ($posts as $p): ?>
        <div class="item">
          <div>
            <a href="/admin/edit.php?id=<?php echo (int)$p['id']; ?>"><?php echo h($p['title']); ?></a>
            <div class="meta">/<?php echo h($p['slug']); ?> · <?php echo h(date('j F Y', strtotime($p['published_at']))); ?></div>
          </div>
          <form method="post" onsubmit="return confirm('Stergi acest articol?');">
            <input type="hidden" name="delete_id" value="<?php echo (int)$p['id']; ?>">
            <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
            <button class="danger" type="submit">Sterge</button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</body>
</html>
